package main

import (
	"fmt"
	"lang.yottadb.com/go/yottadb"
	"os"
	"reflect"
)

const callTableLoc = "/home/dev1/go/testKPay/src/calltab.ci"
const routineLoc  = "/ydbdir/rtns/"

/*
	note
	- to make it easy, all command is run out of TP (in Go, and sample M code)
	- in real application, Golang should control TP even real M code has TP (because it won't support all cases)
 */
func main() {
	var mrtn yottadb.CallMDesc
	defer mrtn.Free()

	defer func(){
		fmt.Println("")
		fmt.Println("done")
	}()

	var errStr yottadb.BufferT
	defer errStr.Free()
	errStr.Alloc(yottadb.YDB_MAX_ERRORMSG)

	// setup environment
	err := os.Setenv("ydb_ci", callTableLoc)
	if err != nil {
		fmt.Println("Can set ydb_ci")
	}

	account0 := os.Args[1]
	account1 := os.Args[2]

	// open account
	nameTH :=""
	nameEN :=""
	prodID :="900000099"
	prodDesc :="Paylater Item"
	fmt.Println("test open account 0 (for position 0) - ", account0)
	mrtn.SetRtnName("OpenAccount")
	retval, err := mrtn.CallMDescT(yottadb.NOTTP, &errStr, 8, account0, nameTH, nameEN, prodID, prodDesc)
	if nil != err {
		panic(fmt.Sprintf("Open account 0 fail: %s", err))
	}
	fmt.Println("Open account 0 : retval =", retval)
	fmt.Println("test open account 1 (for position 1) - ", account1)
	mrtn.SetRtnName("OpenAccount")
	retval, err = mrtn.CallMDescT(yottadb.NOTTP, &errStr, 8, account1, nameTH, nameEN, prodID, prodDesc)
	if nil != err {
		panic(fmt.Sprintf("Open account 0 fail: %s", err))
	}
	fmt.Println("Open account 1 : retval =", retval)

	// open card
	pdailyalimit := "999999999"
	pmonthlyalimit := "999999999"
	pdailytlimit := "999999999"
	pmonthlytlimit := "999999999"
	pdailyausage := "0"
	pmonthlyausage := "0"
	pdailytusage := "0"
	pmonthlytusage := "0"
	wdailyalimit := "999999999"
	wmonthlyalimit := "999999999"
	wdailytlimit := "999999999"
	wmonthlytlimit := "999999999"
	wdailyausage := "0"
	wmonthlyausage := "0"
	wdailytusage := "0"
	wmonthlytusage := "0"
	tdailyalimit := "999999999"
	tmonthlyalimit := "999999999"
	tdailytlimit := "999999999"
	tmonthlytlimit := "999999999"
	tdailyausage := "0"
	tmonthlyausage := "0"
	tdailytusage := "0"
	tmonthlytusage := "0"
	totallimit := "999999999"
	cardtype := "990000099"
	carddesc := "Paylater Card"
	expirydate := ""
	cvv := ""
	cardholdername := ""

	card0 := "990000" + account0
	card1 := "990000" + account1
	fmt.Println("test open card 0 (for position 0) - ", card0)
	mrtn.SetRtnName("OpenAcc")
	retval, err = mrtn.CallMDescT(yottadb.NOTTP, &errStr, 8, card0,account0,pdailyalimit,pmonthlyalimit,pdailytlimit,pmonthlytlimit,pdailyausage,pmonthlyausage,pdailytusage,pmonthlytusage,wdailyalimit,wmonthlyalimit,wdailytlimit,wmonthlytlimit,wdailyausage,wmonthlyausage,wdailytusage,wmonthlytusage,tdailyalimit,tmonthlyalimit,tdailytlimit,tmonthlytlimit,tdailyausage,tmonthlyausage,tdailytusage,tmonthlytusage,totallimit,cardtype,carddesc,expirydate,cvv,cardholdername)
	if nil != err {
		panic(fmt.Sprintf("Open card 0 fail: %s", err))
	}
	fmt.Println("Open card 0 : retval =", retval)
	fmt.Println("test open card 1 (for position 1) - ", card1)
	mrtn.SetRtnName("OpenAcc")
	retval, err = mrtn.CallMDescT(yottadb.NOTTP, &errStr, 8, card1,account1,pdailyalimit,pmonthlyalimit,pdailytlimit,pmonthlytlimit,pdailyausage,pmonthlyausage,pdailytusage,pmonthlytusage,wdailyalimit,wmonthlyalimit,wdailytlimit,wmonthlytlimit,wdailyausage,wmonthlyausage,wdailytusage,wmonthlytusage,tdailyalimit,tmonthlyalimit,tdailytlimit,tmonthlytlimit,tdailyausage,tmonthlyausage,tdailytusage,tmonthlytusage,totallimit,cardtype,carddesc,expirydate,cvv,cardholdername)
	if nil != err {
		panic(fmt.Sprintf("Open card 1 fail: %s", err))
	}
	fmt.Println("Open card 1 : retval =", retval)

	// Disburse Account 1 (Credit amt to account 1, increase balance)
	amount := "1000"
	transcode := "20001"
	vehicleid := ""
	channelid := "K+"
	agentid := ""
	terminalid := "172.16.60.56"
	tai := ""
	ref1 := ""
	ref2 := ""
	comment := "\"ica\":\"257\",\"last_updated_message_id\":\"2004031b4f827252445432\",\"related_account\":\"6300003032\",\"repayment_by\":\"account\",\"request_app_id\":\"509\",\"request_date\":\"20190826235959\",\"transaction_type\":\"online\",\"user_id\":\"test01\""
	rqUID := "2004031b4f827252445432"
	fmt.Println("Disburse Account 1 (Credit amt to account 1, increase balance) - ", account1)
	mrtn.SetRtnName("commonCredit")
	retval, err = mrtn.CallMDescT(yottadb.NOTTP, &errStr, 32, account1,amount,transcode,card1,vehicleid,channelid,agentid,terminalid,tai,ref1,ref2,comment,rqUID)
	if nil != err {
		panic(fmt.Sprintf("Disburse Account 1 fail: %s", err))
	}
	fmt.Println("Disburse Account 1 : retval =", retval)

	// Deposit for repay account 0 (Debit amt to account 0, balance go negative)
	amount = "400"
	transcode = "20001"
	vehicleid = ""
	channelid = "K+"
	agentid = ""
	terminalid = "172.16.60.56"
	tai = ""
	ref1 = ""
	ref2 = ""
	comment = "\"ica\":\"257\",\"last_updated_message_id\":\"2004031b4f827252445432\",\"related_account\":\"6300003032\",\"repayment_by\":\"account\",\"request_app_id\":\"509\",\"request_date\":\"20190826235959\",\"transaction_type\":\"online\",\"user_id\":\"test01\""
	fmt.Println("Deposit for repay account 0 (Debit amt to account 0, balance go negative)")
	mrtn.SetRtnName("commonDebit")
	retval, err = mrtn.CallMDescT(yottadb.NOTTP, &errStr, 32, account0,amount,transcode,card0,vehicleid,channelid,agentid,terminalid,tai,ref1,ref2,comment)
	if nil != err {
		panic(fmt.Sprintf("Deposit for repay Account 0 fail: %s", err))
	}
	fmt.Println("Deposit for repay Account 0 : retval =", retval)

	// allocation for repay : transfer account 1=>0 (account 0 balance go back to 0)
	toacctno := account0
	transcode = "30002"
	amount = "400"
	vehicleid = ""
	vehicletype := ""
	channelid = "K+"
	agentid = "1234"
	terminalid = "172.16.60.56"
	tai = ""
	ref1 = ""
	ref2 = ""
	comment = "\"ica\":\"257\",\"last_updated_message_id\":\"2004031b4f827252445432\",\"related_account\":\"6300003032\",\"repayment_by\":\"account\",\"request_app_id\":\"509\",\"request_date\":\"20190826235959\",\"transaction_type\":\"online\",\"user_id\":\"test01\""
	rqUID = "2004031b4f827252445432"
	toaccno := card0
	fmt.Println("allocation for repay : transfer account 1=>0 (account 0 balance go back to 0)")
	mrtn.SetRtnName("commonTransfer")
	retval, err = mrtn.CallMDescT(yottadb.NOTTP, &errStr, 32, account1,toacctno,transcode,amount,card1,vehicleid,vehicletype,channelid,agentid,terminalid,tai,ref1,ref2,comment,toaccno,rqUID)
	if nil != err {
		panic(fmt.Sprintf("Deposit for repay Account 0 fail: %s", err))
	}
	fmt.Println("Deposit for repay Account 0 : retval =", retval)

	// inquiry balance
	fmt.Println("inquiry balance account 1 - ", account1)
	mrtn.SetRtnName("InqAcctBalance")
	retval, err = mrtn.CallMDescT(yottadb.NOTTP, &errStr, 32, account1)
	if nil != err {
		panic(fmt.Sprintf("InqAcctBalance Account 1 fail: %s", err))
	}
	fmt.Println("InqAcctBalance Account 1 : retval =", retval)

	// inquiry history
	startseq := 1
	num := 20
	numrow := "          "
	moredata := "          "
	mrtn.SetRtnName("InqAccountTrn")
	retval, err = mrtn.CallMDescT(yottadb.NOTTP, &errStr, 50000, account0,startseq,num,&numrow,&moredata)
	if nil != err {
		panic(fmt.Sprintf("InqAccountTrn failed: %s", err))
	}
	fmt.Println("InqAccountTrn (may be mock data) : retval =", retval, " numrow=", numrow, " moredata=", moredata)

	//// test check is this pass-in interface is pointer?
	//Str := "String"
	//StrPt := &Str
	//
	//fmt.Println("Test Pass String : ", isPointer(Str))
	//fmt.Println("Test Pass Pointer : ", isPointer(StrPt))
	//
	//time.Sleep(10 * time.Second)
}

func isPointer(i interface{}) bool {
	return reflect.ValueOf(i).Type().Kind() == reflect.Ptr
}